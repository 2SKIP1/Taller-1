package Consola;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import modulo.Combo;
import modulo.Ingrediente;
import modulo.Pedido;
import modulo.ProductoAjustado;
import modulo.ProductoMenu;
import modulo.Restaurante;

public class Aplicacion 
{	
	
// Incializador de pedido.
	
		public void iniciarPedido(String nombreCliente, String direccionCliente, Restaurante informacionRestaurante, ArrayList<Pedido> listaPedidosGuardados) 
		{	
			int numPedidosGuardados =  listaPedidosGuardados.size();
			Pedido pedidoClienteAbierto = new Pedido(numPedidosGuardados, nombreCliente, direccionCliente);
			
			boolean continuar = true;
			while (continuar)
			{
				try
				{
					mostrarMenuTiposDeProductos(informacionRestaurante);
					int opcion_seleccionada = Integer.parseInt(input("Por favor seleccione el tipo de producto que desea pedir: \n"));
					if (opcion_seleccionada == 1)
					{
						ejecutarProductosSinAjustar(pedidoClienteAbierto, informacionRestaurante);
					}
					else if (opcion_seleccionada == 2)
					{
						ejecutarCombos(pedidoClienteAbierto, informacionRestaurante);
					}
					else if (opcion_seleccionada == 3)
					{
						ejecutarProductosAjustados(pedidoClienteAbierto, informacionRestaurante);
					}
					else if(opcion_seleccionada == 4)
					{
						cerraYGuaradarPedido(pedidoClienteAbierto, listaPedidosGuardados);
						System.out.println("Saliendo del programa...");
						continuar = false;
					}
					
					else 
					{
						System.out.println("Por favor seleccione un tipo de producto disponible.");
						}
				}
				catch (NumberFormatException e)
				{
					System.out.println("Debe seleccionar uno de los numeros de las opciones.");
				}
			}
		}

// Ejecuci�n de productos sin ajustar.
		
		private void ejecutarProductosSinAjustar(Pedido pedidoClienteAbierto, Restaurante informacionRestaurante)
		{
			ArrayList<ProductoMenu> listaProductosMenu = informacionRestaurante.getMenuBase();
			int numProductosMenu = listaProductosMenu.size();
			boolean continuar = true;
			while (continuar)
			{
				try
				{
					mostrarProductosSinAjustar(listaProductosMenu);
					int opcion_seleccionada = Integer.parseInt(input("Por favor seleccione el producto sin ajustar que desea pedir: \n"));
					if (1 <= opcion_seleccionada && opcion_seleccionada <= numProductosMenu)
					{
						ProductoMenu productoMenuAAgregar = listaProductosMenu.get(opcion_seleccionada);
						pedidoClienteAbierto.agregarProductoMenu(productoMenuAAgregar);
					}
					else if (opcion_seleccionada == numProductosMenu + 1) 
					{
						System.out.println("Volviendo al menu anterior...");
						continuar = false;
					}
					else 
					{
						System.out.println("Por favor seleccione un producto sin ajustar disponible.");
					}
				}
				catch (NumberFormatException e)
				{
					System.out.println("Debe seleccionar uno de los numeros de las opciones.");
				}
			}
			}
		
// Ejecucion de combos.
		
	private void ejecutarCombos(Pedido pedidoClienteAbierto, Restaurante informacionRestaurante)
		{
			ArrayList<Combo> listaCombos = informacionRestaurante.getCombos();
			int numCombos = listaCombos.size();
			boolean continuar = true;
			while (continuar)
			{
				try
				{
					mostrarCombos(listaCombos);
					int opcion_seleccionada = Integer.parseInt(input("Por favor seleccione el combo que desea pedir: \n"));
					if (1 <= opcion_seleccionada && opcion_seleccionada <= numCombos)
					{
						Combo ComboAAgregar = listaCombos.get(opcion_seleccionada);
						pedidoClienteAbierto.agregarCombo(ComboAAgregar);
					}
					else if (opcion_seleccionada == numCombos + 1) 
					{
						System.out.println("Volviendo al menu anterior...");
						continuar = false;
					}
					else 
					{
						System.out.println("Por favor seleccione un combo disponible.");
					}
				}
				catch (NumberFormatException e)
				{
					System.out.println("Debe seleccionar uno de los numeros de las opciones.");
				}
			}
		}
		
// Ejecucion de productos ajustados.
	private void ejecutarProductosAjustados(Pedido pedidoClienteAbierto, Restaurante informacionRestaurante)
		{
			ArrayList<ProductoMenu> listaProductosMenu = informacionRestaurante.getMenuBase();
			int numProductosMenu = listaProductosMenu.size();
			boolean continuar = true;
			while (continuar)
			{
				try
				{
					mostrarProductosSinAjustar(listaProductosMenu);
					int opcion_seleccionada = Integer.parseInt(input("Por favor seleccione el producto base que desea pedir: \n"));
					if (1 <= opcion_seleccionada && opcion_seleccionada <= numProductosMenu)
					{
						ProductoMenu productoBase = listaProductosMenu.get(opcion_seleccionada);
						ProductoAjustado productoAjustadoCliente = ejecutarAgregarRemoverIngredientes(productoBase, informacionRestaurante);
						pedidoClienteAbierto.agregarProductoAjustado(productoAjustadoCliente);
					}
					else if (opcion_seleccionada == numProductosMenu + 1) 
					{
						System.out.println("Volviendo al menu anterior...");
						continuar = false;
					}
					else 
					{
						System.out.println("Por favor seleccione un producto base disponible.");
					}
				}
				catch (NumberFormatException e)
				{
					System.out.println("Debe seleccionar uno de los numeros de las opciones.");
				}
			}
		}
		
// Ejecucion de seleccion de ingredientes.
	
	private ProductoAjustado ejecutarAgregarRemoverIngredientes(ProductoMenu productoBase, Restaurante informacionRestaurante) 
	{
		ArrayList<Ingrediente> ingredientesAdicionales = new ArrayList<>();
		ArrayList<Ingrediente> ingredientesRemovidos = new ArrayList<>();
		
		ArrayList<Ingrediente> listaIngredientes = informacionRestaurante.getIngrediente();
		int numIngredientes = listaIngredientes.size();
		boolean continuar = true;
		while (continuar)
		{
			try
			{
				mostrarIngredientes(listaIngredientes);
				int opcion_seleccionada = Integer.parseInt(input("Por favor seleccione el ingrediente que desea agregar/remover: \n"));
				if (1 <= opcion_seleccionada && opcion_seleccionada <= numIngredientes)
				{
					Ingrediente ingredienteSeleccionado = listaIngredientes.get(opcion_seleccionada);
					boolean continuar_ingrediente = true;
					while (continuar_ingrediente)
					{
						try
						{
							System.out.println("Opciones de manipulacion de ingredientes:");
							System.out.println("1 - Agregar");
							System.out.println("2 - Remover");
							System.out.println("2 - Volver al menu anterior");
							int manipulacion_seleccionada = Integer.parseInt(input("Por favor seleccione el ingrediente que desea agregar/remover: \n"));
							if (manipulacion_seleccionada == 1)
							{
								ingredientesAdicionales.add(ingredienteSeleccionado);
							}
							else if (manipulacion_seleccionada == 2)
							{
								ingredientesRemovidos.add(ingredienteSeleccionado);
							}
							else if (manipulacion_seleccionada == 3) 
							{
								System.out.println("Volviendo al menu anterior...");
								continuar_ingrediente = false;
							}
							else 
							{
								System.out.println("Por favor seleccione un ingrediente base disponible.");
							}
						}
						catch (NumberFormatException e)
						{
							System.out.println("Debe seleccionar uno de los numeros de las opciones.");
						}
					}
				}
						
				else if (opcion_seleccionada == numIngredientes + 1) 
				{
					System.out.println("Volviendo al menu anterior...");
					continuar = false;
				}
				else 
				{
					System.out.println("Por favor seleccione un producto base disponible.");
				}
			}
			catch (NumberFormatException e)
			{
				System.out.println("Debe seleccionar uno de los numeros de las opciones.");
			}
		}
		ProductoAjustado productoAjustadoCliente = new ProductoAjustado(productoBase, ingredientesAdicionales, ingredientesRemovidos);
		
	return	productoAjustadoCliente;	
	}
 
		
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Exposicion de opciones y ejecucion de ordenes.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	
// Exposicion del menu principal.
	
	public void mostrarMenuPrincipal() 
	{
		System.out.println("Tipos de operaciones:\n");
		System.out.println("1. Ingreso de pedidos\n");
		System.out.println("2. Consulta de pedidos guardados en base de datos\n");
		System.out.println("3. Salir del programa\n");
	}
	
// Exposicion del menu de tipos de productos.
	
	private void mostrarMenuTiposDeProductos(Restaurante informacionRestaurante) 
	{
		System.out.println("Tipo de productos:\n");
		System.out.println("1. Productos sin ajustar\n");
		System.out.println("2. Combos\n");
		System.out.println("3. Productos Ajustados\n");
		System.out.println("4. Cerrar y guardar pedido\n");
	}
	
// Exposicion del menu de opciones de productos sin ajustar.
	
	private void mostrarProductosSinAjustar(ArrayList<ProductoMenu> listaProductosMenu) 
	{	int pos = 1;
		System.out.println("Opciones de productos sin ajustar:\n");
		
		for (ProductoMenu item : listaProductosMenu) 
		{
			String descripcionItem = item.generarTextoFactura();
			System.out.println(descripcionItem);
			pos ++;
		}
		System.out.println(pos + " - Volver al menu anterior\n");
	}
	
// Exposicion del menu de combos.
	
	private void mostrarCombos(ArrayList<Combo> listaCombos) 
	{	int pos = 1;
	System.out.println("Opciones de productos sin ajustar:\n");
	
	for (Combo item : listaCombos) 
	{
		String descripcionItem = item.generarTextoFactura();
		ArrayList<ProductoMenu> listaProductosBaseCombo = item.getProductos();
		System.out.println(descripcionItem);
		
		System.out.println("El combo trae:");
		for (ProductoMenu producto : listaProductosBaseCombo) 
		{
			String nombreProducto = producto.getNombre();
			int precioProducto = producto.getPrecio();
			String opcionProductoParcial = String.format("%10d", nombreProducto);
			int spacingProducto = 90 - opcionProductoParcial.length();
			String OpcionFinalProducto = String.format(opcionProductoParcial + "%" + spacingProducto +"d", precioProducto + " COP\n");
			System.out.println(OpcionFinalProducto);
		}
		pos ++;
	}
	System.out.println(pos + " - Volver al menu anterior\n");
}
	
// Exposici�n del menu de ingredientes
	
	private void mostrarIngredientes(ArrayList<Ingrediente> listaIngredientes) 
	{	int pos = 1;
		System.out.println("Opciones de ingredientes:\n");
		
		for (Ingrediente item : listaIngredientes) 
		{
			String nombreItem = item.getNombre();
			int costoItem = item.getCostoAdicional();
			String opcionParcial = pos + " - " + nombreItem;
			int spacing = 90 - opcionParcial.length();
			String OpcionFinal = String.format(opcionParcial + "%" + spacing +"d", "+" + costoItem + " COP\n");
			System.out.println(OpcionFinal);
			pos ++;
		}
		System.out.println(pos + " - Volver al menu anterior\n");
	}
	
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Metodos.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	
// Ejecucion de Opcion 1.

	public void ejecutarOpcion1(Restaurante informacionRestaurante, ArrayList<Pedido> listaPedidosGuardados) 
	{	
		System.out.println("Inicializando pedido...\n");
		String nombreCliente = input("Por favor ingrese el nombre del cliente: \n");
		String direccionCliente = input("Por favor ingrese la direccion del cliente: \n");
		iniciarPedido(nombreCliente, direccionCliente, informacionRestaurante, listaPedidosGuardados);	
	}
	
// Ejecucion de Opcion 2.	
	public void ejecutarOpcion2(Restaurante informacionRestaurante, ArrayList<Pedido> listaPedidosGuardados) 
	{	
		int opcion_seleccionada = Integer.parseInt(input("Por favor ingrese el id del pedido a consultar: \n"));
		int num_pedidos = listaPedidosGuardados.size();
		
		int posicionItemBuscado = 0;
		boolean encontrado = false;
		int pos_pedido = 1;
		while (!encontrado && pos_pedido <= num_pedidos) 
		{
			Pedido item = listaPedidosGuardados.get(pos_pedido);
			int idItem = item.getIdPedido();
			
			if (idItem == opcion_seleccionada) 
			{
				encontrado = true;
				posicionItemBuscado = pos_pedido;
			}
			
			pos_pedido ++;
		}
		
		if (encontrado) 
		{
			Pedido PedidoItemBuscado = listaPedidosGuardados.get(posicionItemBuscado);
			mostrarPedido(PedidoItemBuscado);
		}
		else 
		{
			System.out.println("Pedido no encontrado");
		}
	}
	
// Expone la informacion del pedido en consola
	private void mostrarPedido(Pedido item) 
	{
		int idPedido = item.getIdPedido();
		String nombreCliente = item.getNombreCliente();
		String direccionCliente = item.getDireccionCliente();
		ArrayList<ProductoMenu> listaProductosMenu = item.getListaProductosMenuCliente();
		ArrayList<ProductoMenu> listaCombos = item.getListaProductosMenuCliente();
		ArrayList<ProductoMenu> listaProductosAjustados = item.getListaProductosMenuCliente();
		
		String lineaSeparadoraPedido = "###################################################################################";
		String lineaSeparadoraTipoInformacion = "-----------------------------------------------------------------------------------";
		String lineaSeparadoraColumna = "///////////////////////////////////////////////////////////////////////////////////";

		
		System.out.println(lineaSeparadoraPedido);
		System.out.println("Pedido No." + idPedido);
		System.out.println(lineaSeparadoraPedido);
		
		System.out.println(lineaSeparadoraColumna);
		
	}
	
// Funcion de carga de pedidos guardados.
	
	private ArrayList<Pedido> cargarPedidosGuardados(Restaurante informacionRestaurante) throws FileNotFoundException, IOException
	{
		Map<String, ProductoMenu> mapaProductosMenu = informacionRestaurante.getMapaMenuBase();
		Map<String, Combo> mapaCombos = informacionRestaurante.getMapaCombo();
		Map<String, Ingrediente> mapaIngredientes = informacionRestaurante.getmapaIngredientes();
		
		ArrayList<Pedido> listaPedidosguardados = new ArrayList<>();
		int numPedidos = -1;
		
		String path = System.getProperty("user.dir");
		String referenciaArchivoPedidos = path + "\\data\\pedidos.txt";
		BufferedReader br = new BufferedReader(new FileReader(referenciaArchivoPedidos));
		String linea = br.readLine();
		
		while (linea != null) 
		{
			String[] ComponentesRecibo = linea.split(";");
			String nombreCliente = ComponentesRecibo[1];
			String direccionCliente = ComponentesRecibo[2];
			
			Pedido pedidoCliente = new Pedido(numPedidos, nombreCliente, direccionCliente);
			
			String listaProductosMenuString = ComponentesRecibo[3];
			String[] listaProductosMenu = listaProductosMenuString.split(",");
			for (String item :  listaProductosMenu) 
			{
				ProductoMenu itemProductoMenu = mapaProductosMenu.get(item);
				pedidoCliente.agregarProductoMenu(itemProductoMenu);
			}
			
			String listaCombosString = ComponentesRecibo[4];
			String[] listaCombos = listaCombosString.split(",");
			for (String item : listaCombos)
			{
				Combo itemCombo = mapaCombos.get(item);
				pedidoCliente.agregarCombo(itemCombo);
			}
	
			String listaProductosAjustadosString = ComponentesRecibo[5];
			String[] listaProductosAjustados = listaProductosAjustadosString.split(">");
			for (String item : listaProductosAjustados)
			{
				String[] elementosProductoAjustado = item.split("<");
				String productoBaseString = elementosProductoAjustado[0];
				String listaIngredientesAdicionalesString = elementosProductoAjustado[1];
				String listaIngredientesRemovidosString = elementosProductoAjustado[2];
				
				ProductoMenu productoBase = mapaProductosMenu.get(productoBaseString);
				
				String[] listaIngredientesAdicionales = listaIngredientesAdicionalesString.split(" ,");
				String[] listaIngredientesRemovidos = listaIngredientesRemovidosString.split(" ,");
				
				ArrayList<Ingrediente> ingredientesAdicionales = new ArrayList<>();
				for (String itemAdicional : listaIngredientesAdicionales) 
				{
					Ingrediente itemIngredienteAdicional = mapaIngredientes.get(itemAdicional);
					ingredientesAdicionales.add(itemIngredienteAdicional);
				}
				
				ArrayList<Ingrediente> ingredientesRemovidos = new ArrayList<>();
				for (String itemRemovido : listaIngredientesRemovidos) 
				{
					Ingrediente itemIngredienteRemovido = mapaIngredientes.get(itemRemovido);
					ingredientesRemovidos.add(itemIngredienteRemovido);
				}
				
				ProductoAjustado itemProductoAjustado = new ProductoAjustado(productoBase, ingredientesAdicionales, ingredientesRemovidos);
				pedidoCliente.agregarProductoAjustado(itemProductoAjustado);
			}
			
			listaPedidosguardados.add(pedidoCliente);
			numPedidos ++;
		}
		return listaPedidosguardados;
	}
	
	private void cerraYGuaradarPedido(Pedido pedidoClienteAbierto, ArrayList<Pedido> listaPedidosGuardados) 
	{
		String path = System.getProperty("user.dir");
		String referenciaProductosMenu = path + "\\data\\registroPedidos.txt";
		try {
			FileWriter writer = new FileWriter(referenciaProductosMenu);
			
			for (Pedido pedidoGuardado : listaPedidosGuardados) {
			String lineaArchivo = generarLineaDeTextoRecibo(pedidoGuardado);
			writer.write(lineaArchivo);
			}
			String lineaFinalArchivo = generarLineaDeTextoRecibo(pedidoClienteAbierto);
			writer.write(lineaFinalArchivo);
			writer.close();
		} 
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private String generarLineaDeTextoRecibo(Pedido pedidoEnProcesamiento) 
	{
		int idCliente = pedidoEnProcesamiento.getIdPedido();
		String nombreCliente = pedidoEnProcesamiento.getNombreCliente();
		String direccionCliente = pedidoEnProcesamiento.getDireccionCliente();
		ArrayList<ProductoMenu> productosMenuPedido = pedidoEnProcesamiento.getListaProductosMenuCliente();
		ArrayList<Combo> CombosPedido = pedidoEnProcesamiento.getListaCombosCliente();
		ArrayList<ProductoAjustado> productosAjustadosPedido = pedidoEnProcesamiento.getListaProductoAjustadoCliente();
		
		String textoProductosMenuPedido = "";
		for (ProductoMenu itemProductoMenu : productosMenuPedido) 
		{
			String nombreItemProductoMenu = itemProductoMenu.getNombre();
			textoProductosMenuPedido += "," + nombreItemProductoMenu;
		}
		
		String textoCombos = "";
		for (Combo itemCombo : CombosPedido) 
		{
			String nombreItemCombo = itemCombo.getNombre();
			textoCombos += "," + nombreItemCombo;
		}
		
		String textoProductosAjustados = "";
		for (ProductoAjustado itemProductoAjustado : productosAjustadosPedido) 
		{
			String nombreProductoBase = itemProductoAjustado.getNombre();
			textoProductosAjustados += ">" + nombreProductoBase;
		}
		
		String LineaTextoReciboFinal = idCliente + ";" + nombreCliente + ";" + direccionCliente + ";" + 
				textoProductosMenuPedido + ";" + textoCombos + ";" + textoProductosAjustados;
		return LineaTextoReciboFinal;
	}
	
		
	
	public String input(String mensaje)
	{
		try{
			System.out.print(mensaje + ": ");
			BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
			return reader.readLine();}
		catch (IOException e){
			System.out.println("Error leyendo de la consola");
			e.printStackTrace();}
		return null;}
	
	public static void main(String[] args) throws FileNotFoundException, IOException
	{
		Aplicacion aplicacion = new Aplicacion();
		aplicacion.ejecutarAplicacion();
	}

	private void ejecutarAplicacion() throws FileNotFoundException, IOException {
		System.out.println("Bienvenidos al restaurante\n");
		System.out.println("Cargando informaci�n...\n");
		
		Restaurante informacionRestaurante = new Restaurante();
		informacionRestaurante.cargarInformacionRestaurante();
		ArrayList<Pedido> listaPedidosGuardados = cargarPedidosGuardados(informacionRestaurante);
		boolean continuar = true;
		while (continuar)
		{
			try
			{
				mostrarMenuPrincipal();
				int opcion_seleccionada = Integer.parseInt(input("Por favor seleccione el tipo de operacion: \n"));
				if (opcion_seleccionada == 1)
				{
					ejecutarOpcion1(informacionRestaurante, listaPedidosGuardados);
				}
				else if (opcion_seleccionada == 2)
				{
					ejecutarOpcion2(informacionRestaurante, listaPedidosGuardados);
				}
				else if (opcion_seleccionada == 3) 
				{
					System.out.println("Saliendo del programa...");
					continuar = false;
					}
				else 
				{
					System.out.println("Por favor seleccione un tipo de producto disponible.");
					}
			}
			catch (NumberFormatException e)
			{
				System.out.println("Debe seleccionar uno de los numeros de las opciones.");
			}
		}
	}}
