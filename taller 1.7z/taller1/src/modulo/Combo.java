package modulo;

import java.util.ArrayList;

public class Combo implements Producto
{
 	private double descuento;
 	
 	private String nombreCombo;
 	
 	private ArrayList<ProductoMenu> productos;
 	
 	public Combo(String elNombre, double elDescuento)
 	{
 		this.nombreCombo = elNombre;
 		this.descuento = elDescuento;
 		this.productos = new ArrayList<>();
 	}
 	
 	public String getNombre() {
 		return nombreCombo;
 	}
 	
 	public int getPrecio() {
 		int precioTotal = 0;
 		for (Producto item : productos)
 		{
 			int precioPerticular = item.getPrecio();
 			precioTotal += precioPerticular;
 		}
 		return precioTotal;
 	}
 	
 	public double getDescuento() 
 	{
 		return descuento;
 	}
 	
 	public ArrayList<ProductoMenu> getProductos() 
 	{
 		return productos;
 	}
 	
 	public void agregarItemACombo(ProductoMenu itemCombo)
 	{
 		productos.add(itemCombo);
 	}
 		
 	
 	public String generarTextoFactura()
 	{
 		int precioTotal = getPrecio();
	
		String facturaDescuento = "-%" + descuento;
		int espacio1 = 50 - nombreCombo.length();
		int espacio2 = 40 - facturaDescuento.length();
		String facturaParcial = String.format(nombreCombo + "%" + espacio1 +"d", "-%" + descuento);
		String facturaFinal = String.format(facturaParcial + "%" + espacio2 +"d", precioTotal + " COP\n");
 		
 		return facturaFinal;
 	}

}