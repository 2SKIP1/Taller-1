package modulo;

import java.util.ArrayList;

public class Pedido 
{
	
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Atributos.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	
	private int numeroPedidos;
	
	private int idPedido;
	
	private String nombreCliente;
	
	private String direccionCliente;
	
	private ArrayList<ProductoMenu> listaProductosMenuCliente;
	
	private ArrayList<Combo> listaCombosCliente;
	
	private ArrayList<ProductoAjustado> listaProductosAjustadoCliente;
	
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Constructor.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	
	public Pedido(int numeroPedidosGuardados, String elNombreCliente, String laDireccionCliente) 
	{
		this.numeroPedidos = numeroPedidosGuardados;
		this.idPedido = numeroPedidosGuardados + 1;
		this.nombreCliente = elNombreCliente;
		this.direccionCliente = laDireccionCliente;
		this.listaProductosMenuCliente = new ArrayList<>();
		this.listaCombosCliente = new ArrayList<>();
		this.listaProductosAjustadoCliente = new ArrayList<>();
	}
	
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Metodos.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	public int getNumeroPedidos() 
	{
		return numeroPedidos;
	}
	
	public int getIdPedido() 
	{
		return idPedido;
	}
	
	public String getNombreCliente()
	{
		return nombreCliente;
	}
	
	public String getDireccionCliente() 
	{
		return direccionCliente;
	}
	
	public ArrayList<ProductoMenu> getListaProductosMenuCliente() 
	{
		return listaProductosMenuCliente;
	}
	
	public ArrayList<Combo> getListaCombosCliente() 
	{
		return listaCombosCliente;
	}
	
	public ArrayList<ProductoAjustado> getListaProductoAjustadoCliente() 
	{
		return listaProductosAjustadoCliente;
	}
	
// Adicion de productos no ajustados.
	
	public void agregarProductoMenu(ProductoMenu nuevoItem)
	{
		listaProductosMenuCliente.add(nuevoItem);
	}
	
// Adicion de combos.	
	public void agregarCombo(Combo nuevoItem)
	{
		listaCombosCliente.add(nuevoItem);
	}
	
// Adicion de productos ajustados.	
	public void agregarProductoAjustado(ProductoAjustado nuevoItem)
	{
		listaProductosAjustadoCliente.add(nuevoItem);
	}
	
}