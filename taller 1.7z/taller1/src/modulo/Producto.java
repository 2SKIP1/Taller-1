package modulo;

interface Producto{
	public String getNombre();
	
	public int getPrecio();
	
	public String generarTextoFactura();
}