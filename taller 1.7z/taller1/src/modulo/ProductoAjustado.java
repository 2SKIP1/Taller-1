package modulo;

import java.util.ArrayList;
import java.util.Collections;

public class ProductoAjustado implements Producto
{
	private String nombreAjustado;
	
	private int precioAjustado;
	
	public ProductoAjustado(Producto productoBase, ArrayList<Ingrediente> ingredientesAdicionales, ArrayList<Ingrediente> ingredientesRemovidos) 
	{
		ArrayList<String> nombresIngredientesAdicionales = new ArrayList<>();
		ArrayList<String> nombresIngredientesRemovidos = new ArrayList<>();
		
		String nombreProductoBase = productoBase.getNombre();
		String nombreProductoAjustado = nombreProductoBase + "<";
		int precioTotal = productoBase.getPrecio();
		
		for (Ingrediente item : ingredientesAdicionales) 
		{
			String nombreIngrediente = item.getNombre();
			int precioIngrediente = item.getCostoAdicional();
			nombresIngredientesAdicionales.add(nombreIngrediente);
			precioTotal += precioIngrediente;
		}
		
		for (Ingrediente item : ingredientesRemovidos) 
		{
			String nombreIngrediente = item.getNombre();
			nombresIngredientesRemovidos.add(nombreIngrediente);
		}
		
		Collections.sort(nombresIngredientesAdicionales);
		Collections.sort(nombresIngredientesRemovidos);
		
		for (String nombreItem : nombresIngredientesAdicionales) 
		{
			nombreProductoAjustado += " ," + nombreItem;
		}
		
		nombreProductoAjustado += " ,<";
		
		for (String nombreItem : nombresIngredientesRemovidos) 
		{
			nombreProductoAjustado += " ," + nombreItem;
		}
		nombreProductoAjustado += " ,";
		
		this.nombreAjustado = nombreProductoAjustado;
		this.precioAjustado = precioTotal;
	}

	public String getNombre() {
		return nombreAjustado;
	}

	public int getPrecio() {
		return precioAjustado;
	}

	public String generarTextoFactura() 
	{
		String[] partesFactura = nombreAjustado.split("<");
		String nombreProductoBase = partesFactura[0];
		String ingredientesAgregados = partesFactura[1];
		String ingredientesRemovidos = partesFactura[2];
		
		String textoIngredientesAgregados = "";
		String textoIngredientesRemovidos = "";
		
		int lengthIngredientesAgregados = ingredientesAgregados.length();
		int lengthIngredientesRemovidos = ingredientesRemovidos.length();
		
		if (2 < lengthIngredientesAgregados && 2 < lengthIngredientesRemovidos) 
		{
			textoIngredientesAgregados += ingredientesAgregados.substring(2, lengthIngredientesAgregados - 2);
			textoIngredientesRemovidos += ingredientesRemovidos.substring(2, lengthIngredientesRemovidos - 2);
		}
		else if (2 < lengthIngredientesAgregados && 2 == lengthIngredientesRemovidos) 
		{
			textoIngredientesAgregados += ingredientesAgregados.substring(2, lengthIngredientesAgregados - 2);
			textoIngredientesRemovidos += "nada";
		}
		else if (2 == lengthIngredientesAgregados && 2 < lengthIngredientesRemovidos) 
		{
			textoIngredientesRemovidos += ingredientesRemovidos.substring(2, lengthIngredientesRemovidos - 2);
			textoIngredientesAgregados += "nada";
		}
		else 
		{
			textoIngredientesAgregados += "nada";
			textoIngredientesRemovidos += "nada";
		}
		
		String facturaParcial = nombreProductoBase + " con " + textoIngredientesAgregados + " y sin " + textoIngredientesRemovidos;
		int spacing = 90 - facturaParcial.length();
		String facturaFinal = String.format(facturaParcial + "%" + spacing +"d", precioAjustado + " COP\n");
		
		return facturaFinal;
	}
	
}