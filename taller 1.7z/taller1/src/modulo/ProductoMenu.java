package modulo;

public class ProductoMenu implements Producto
{
	private String nombre;
	
	private int precioBase;
	
	public ProductoMenu(String elNombre, int elPrecioBase)
	{
		this.nombre = elNombre;
		this.precioBase = elPrecioBase;
	}
	
	public String getNombre()
	{
		return nombre;
	}
	
	public int getPrecio()
	{
		return precioBase;
	}
	
	public String generarTextoFactura()
	{
		int spacing = 90 - nombre.length();
		String facturaFinal = String.format(nombre + "%" + spacing +"d", precioBase + " COP\n");

		return facturaFinal;
	}
}