package modulo;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class Restaurante 
{	
	
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Atributos.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	
	private ArrayList<ProductoMenu> listaProductosMenu;
	private ArrayList<Combo> listaCombos;
	private ArrayList<Ingrediente> listaIngredientes;
	private Map<String, ProductoMenu> mapaProductosMenu;
	private Map<String, Combo> mapaCombos;
	private Map<String, Ingrediente> mapaIngredientes;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Constructor.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	
	public Restaurante() 
	{
		this.listaProductosMenu = new ArrayList<>();
		this.listaCombos = new ArrayList<>();
		this.listaIngredientes = new ArrayList<>();
		this.mapaProductosMenu = new HashMap<>();
		this.mapaCombos = new HashMap<>();
		this.mapaIngredientes = new HashMap<>();
	}
	
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Metodos.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	public ArrayList<ProductoMenu> getMenuBase() 
	{
		return listaProductosMenu;
	}
	
	public ArrayList<Combo> getCombos() 
	{
		return listaCombos;
	}
	
	public ArrayList<Ingrediente> getIngrediente() 
	{
		return listaIngredientes;
	}
	
	public Map<String, ProductoMenu> getMapaMenuBase() 
	{
		return mapaProductosMenu;
	}
	
	public Map<String, Combo> getMapaCombo() 
	{
		return mapaCombos;
	}
	
	public Map<String, Ingrediente> getmapaIngredientes() 
	{
		return mapaIngredientes;
	}

// Cargue de la lista de productos.

	public ArrayList<ProductoMenu> cargarMenu(String referenciaProductosMenu) throws FileNotFoundException, IOException 
	{
		ArrayList<ProductoMenu> laListaProductosMenu = new ArrayList<ProductoMenu>();
		BufferedReader br = new BufferedReader(new FileReader(referenciaProductosMenu));
		String linea = br.readLine();
		
		while (linea != null) 
		{
			String[] partes = linea.split(";");
			String elNombre = partes[0];
			int elPrecioBase = Integer.parseInt(partes[1]);
			ProductoMenu elProductoMenuCargado = new ProductoMenu(elNombre, elPrecioBase);
			laListaProductosMenu.add(elProductoMenuCargado);
			linea = br.readLine();
		}
		br.close();
		
		return laListaProductosMenu;
	}
	
// Cargue del mapa de productos.

	public Map<String, ProductoMenu> cargarMapaProductos(ArrayList<ProductoMenu> listaProductosMenuCargado) 
	{
		Map<String, ProductoMenu> elMapaProductosMenu = new HashMap<>();
		for (ProductoMenu item : listaProductosMenuCargado)
		{
			String elNombre = item.getNombre();
			elMapaProductosMenu.put(elNombre, item);
		}
		return elMapaProductosMenu;
	}
	
// Cargue de la lista de combos.
	
	
	public ArrayList<Combo> cargarCombos(String referenciaCombos, Map<String, ProductoMenu> MapaProductosMenu) throws FileNotFoundException, IOException
	{
		ArrayList<Combo> laListaCombos = new ArrayList<Combo>();
		BufferedReader br = new BufferedReader(new FileReader(referenciaCombos));
		String linea = br.readLine();
		
		while (linea != null) 
		{	
			String[] partes = linea.split(";");
			String elNombreCombo = partes[0];
			String elDescuentoPorcentual = partes[1];
			double elDescuento = Double.parseDouble(elDescuentoPorcentual.substring(0, elDescuentoPorcentual.length() - 1));
			String nombreProducto1 = partes[2];
			String nombreProducto2 = partes[3];
			String nombreProducto3 = partes[4];
			
			ProductoMenu objetoProducto1 = MapaProductosMenu.get(nombreProducto1);
			ProductoMenu objetoProducto2 = MapaProductosMenu.get(nombreProducto2);
			ProductoMenu objetoProducto3 = MapaProductosMenu.get(nombreProducto3);
					
			int precioProducto1 = objetoProducto1.getPrecio();
			int precioProducto2 = objetoProducto2.getPrecio();
			int precioProducto3 = objetoProducto3.getPrecio();
			
			int precioDescuentoProducto1 = (int) (precioProducto1 - precioProducto1*(elDescuento/10));
			int precioDescuentoProducto2 = (int) (precioProducto2 - precioProducto2*(elDescuento/10));
			int precioDescuentoProducto3 = (int) (precioProducto3 - precioProducto3*(elDescuento/10));
			
			ProductoMenu productoCombo1 = new ProductoMenu(nombreProducto1, precioDescuentoProducto1);
			ProductoMenu productoCombo2 = new ProductoMenu(nombreProducto2, precioDescuentoProducto2);
			ProductoMenu productoCombo3 = new ProductoMenu(nombreProducto3, precioDescuentoProducto3);
			
			Combo elComboCargado = new Combo(elNombreCombo, elDescuento);
			elComboCargado.agregarItemACombo(productoCombo1);
			elComboCargado.agregarItemACombo(productoCombo2);
			elComboCargado.agregarItemACombo(productoCombo3);
			
			laListaCombos.add(elComboCargado);
			linea = br.readLine();
		}
		br.close();
		return laListaCombos;
	}
	
// Cargue del mapa de combos.

	public Map<String, Combo> cargarMapaCombos(ArrayList<Combo> listaCombosCargados) 
	{
		Map<String, Combo> elMapaCombos = new HashMap<>();	
		for (Combo item : listaCombosCargados) 
		{	
			String elNombreCombo = item.getNombre();
			elMapaCombos.put(elNombreCombo, item);
		}
		return elMapaCombos;
	}


// Cargue de la lista de ingredientes.
	
	public ArrayList<Ingrediente> cargarIngredientes(String referenciaIngredientes) throws FileNotFoundException, IOException
	{
		ArrayList<Ingrediente> laListaIngredientes = new ArrayList<Ingrediente>();
		BufferedReader br = new BufferedReader(new FileReader(referenciaIngredientes));
		String linea = br.readLine();
		
		while (linea != null) 
		{
			String[] partes = linea.split(";");
			String elNombre = partes[0];
			int elPrecioBase = Integer.parseInt(partes[1]);
			Ingrediente elIngredienteCargado = new Ingrediente(elNombre, elPrecioBase);
			laListaIngredientes.add(elIngredienteCargado);
			linea = br.readLine();
		}
		br.close();
		return laListaIngredientes;
	}

// Cargue del mapa de ingredientes.
	
	public Map<String, Ingrediente> cargarMapaIngredientes(ArrayList<Ingrediente> listaIngredientes) 
	{
		Map<String, Ingrediente> elMapaIngredientes = new HashMap<>();
		for (Ingrediente item: listaIngredientes) 
		{
			String elNombre = item.getNombre();
			elMapaIngredientes.put(elNombre, item);
		}
		return elMapaIngredientes;
	}
	
// Cargue de la informacion de los archivos.
	
	public void cargarInformacionRestaurante() throws FileNotFoundException, IOException
	{
		String path = System.getProperty("user.dir");
		String referenciaProductosMenu = path + "\\data\\menu.txt";
		String referenciaCombos = path + "\\data\\combos.txt";
		String referenciaIngredientes = path + "\\data\\ingredientes.txt";
		
		ArrayList<ProductoMenu> listaProductosMenuCargado = cargarMenu(referenciaProductosMenu);
		Map<String, ProductoMenu> mapaProductosCargados = cargarMapaProductos(listaProductosMenuCargado);
		this.listaProductosMenu = listaProductosMenuCargado;
		this.mapaProductosMenu = mapaProductosCargados;
		
		ArrayList<Combo> listaCombosCargados = cargarCombos(referenciaCombos, mapaProductosCargados);
		Map<String, Combo> mapaCombosCargados = cargarMapaCombos(listaCombosCargados);
		
		this.listaCombos = listaCombosCargados;
		this.mapaCombos = mapaCombosCargados;
		
		ArrayList<Ingrediente> listaIngredientes = cargarIngredientes(referenciaIngredientes);
		Map<String, Ingrediente> mapaIngredientesCargados = cargarMapaIngredientes(listaIngredientes);
		
		this.listaIngredientes = listaIngredientes;
		this.mapaIngredientes = mapaIngredientesCargados;
	}
	
}