package modulo;
import java.io.FileWriter;
import java.io.IOException;

public class Test {

	public static void main(String[] args) {
		String path = System.getProperty("user.dir");
		String referenciaProductosMenu = path + "\\data\\";
		try {
			FileWriter writer = new FileWriter(referenciaProductosMenu + "poem.txt");
			writer.write("linea 1");
			writer.close();
		} 
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}